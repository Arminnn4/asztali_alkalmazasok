﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kockak
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hányszor dobjuk a dobókockákat?(3) ");
            int Nszam = int.Parse(Console.ReadLine());

            Random rnd = new Random();
            int anninyer = 0;
            int panninyer = 0;

            for (int i = 0; i < Nszam; i++)
            {

                int kocka1 = rnd.Next(1, 7);
                int kocka2 = rnd.Next(1, 7);
                int kocka3 = rnd.Next(1, 7);
                int osszeg = kocka1 + kocka2 + kocka3;
                string nyertes = (osszeg < 10) ? "Anni" : "Panni";
                Console.WriteLine($"Dobás: {kocka1} + {kocka2} + {kocka3} = {osszeg}  Nyert: {nyertes}");
                if (nyertes == "Anni")
                {
                    anninyer++;
                }
                else
                {
                    panninyer++;
                }
            }
            Console.WriteLine($"\nA játék során {anninyer} alkalommal Anni, {panninyer} alkalommal Panni nyert.");
            Console.ReadKey();
        }
    }
}

