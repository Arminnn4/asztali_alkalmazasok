﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._06
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string[] szavak = { "fuvola", "csirke", "adatok", "asztal", "fogoly", "bicska", "farkas", "almafa", "babona", "gerinc", "dervis", "bagoly", "ecetes", "angyal", "boglya" };


            Random rnd = new Random();
            int randomIndex = rnd.Next(szavak.Length);
            string rejtettszo = szavak[randomIndex];
            int szohossz = szavak.Length;
            string tippeltszo = new string('.', szohossz);
            while (true)
            {
                Console.WriteLine("Rejtett szó: " + tippeltszo);
                Console.Write("Tippeld meg a szót (vagy írd be 'stop'-ot a kilépéshez): ");
                string tipp = Console.ReadLine();
                if (tipp == "stop")
                {
                    break;
                }
                if (tipp.Length != szohossz)
                {
                    Console.WriteLine("A tippnek pontosan 6 karakter hosszúnak kell lennie.");
                    continue;
                }
                for (int i = 0; i < szohossz; i++)
                {
                    if (tipp[i] == rejtettszo[i])
                    {
                        tippeltszo = tippeltszo.Remove(i, 1).Insert(i, tipp[i].ToString());

                        {
                            Console.WriteLine("Gratulálok! Kitaláltad a rejtett szót: " + rejtettszo);
                            break;
                        }
                    }
                }
            }
        }
    }
}
