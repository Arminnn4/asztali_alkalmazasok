﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szamologepcucc
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program kiszámolja amit csak akarsz írj, be két számot ");
            double eredmeny;Console.WriteLine("Írd be az első számot");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("írd be a második számot");
            double b = Convert.ToDouble(Console.ReadLine());
            
            Console.WriteLine("Válassza ki a műveletet:+,-,*,/");
            string muvelet=Console.ReadLine();
            bool vege = false;
            do
            {
                switch (muvelet)
                {
                    case "+":
                        eredmeny = (a + b);
                        Console.Write(eredmeny);
                        Console.WriteLine("szeretnél még játszani?" + vege);
                        break;

                    case "-":
                        eredmeny = (a - b);
                        Console.Write(eredmeny);
                        break;
                    case "*":
                        eredmeny = (a * b);
                        Console.Write(eredmeny);
                        break;
                    case "/":
                        eredmeny = (a / b);
                        Console.Write(eredmeny);

                        break;

                }



            } while (vege = false);
            

               
                
            Console.ReadLine();
        }
    }
}
