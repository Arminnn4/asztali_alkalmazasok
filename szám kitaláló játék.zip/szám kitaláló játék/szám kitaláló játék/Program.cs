﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szám_kitaláló_játék
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            int szam = rnd.Next(1,101);
            int tipp = 0;
            

            Console.WriteLine("Ez egy szám kitaláló játék.");







            Console.WriteLine("Mondj Egy számot :3");
            tipp = Convert.ToInt32(Console.Read());

            while (tipp != szam)
            {
               
                {
                    
                    
                    if (tipp > szam)
                    {

                        Console.WriteLine("a szám nagyobb mint " + tipp);
                        Console.Read();
                    }

                    else if (tipp < szam)
                    {
                        Console.WriteLine("a szám kisebb mint " + tipp);
                        Console.Read();
                    }

                    else
                    {
                        Console.WriteLine("szép munka a szám " + tipp + "volt");
                        Console.Read();
                    }
                }






            }
        }
    } }
