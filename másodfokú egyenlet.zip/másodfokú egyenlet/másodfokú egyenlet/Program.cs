﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace másodfokú_egyenlet
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ez a program megodlja a másodfokú egyenletet");



            Console.WriteLine("A másodfokú egyenlet fő eggyütthatóját írd ide");



            double a = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("A másodfokú egyenlet másik eggyütthatóját írd ide");


            double b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("A másodfokú egyenlet harmadik együtthatóját írd ide");

            double c = Convert.ToDouble(Console.ReadLine());

            double dsz = b * b - 4 * a * c;
            Console.WriteLine("a disztrkimináns értéke: {0}", dsz);

            

            if (dsz < 0)
            {
                Console.WriteLine("nincs megoldás");
            }
            else
                 {
                    double megoldas1 = ((-1) * b + Math.Sqrt(dsz)) / (2 * a);
                    double megoldas2 = ((-1) * b - Math.Sqrt(dsz)) / (2 * a);
                    Console.WriteLine("Az első megoldás: x1={0:0.00} \nA második megoldás: x2={1:0.00}", megoldas1 , megoldas2);
                    Console.ReadLine();

                 }

            Console.ReadLine();







        }
    }
}
