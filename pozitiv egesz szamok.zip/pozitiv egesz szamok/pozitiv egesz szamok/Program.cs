﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pozitiv_egesz_szamok
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> szamok = new List<int>();

            while (true)
            {
                Console.Write("Kérem adjon meg egy pozitív egész számot  a befejezéshez: ");
                if (int.TryParse(Console.ReadLine(), out int szam))
                {
                    if (szam == 0)
                    {
                        break;
                    }
                    else if (szam > 0)
                    {
                        szamok.Add(szam);
                    }
                    else
                    {
                        Console.WriteLine("Csak pozitiv egész szám lehet!");
                    }
                }
                else
                {
                    Console.WriteLine("Érvénytelen bemenet. Kérem adjon meg egy pozitív egész számot!");
                }
            }


            Console.WriteLine("A listába szereplő számok: " + szamok.Count);
            Console.WriteLine("A lista elemei:");
            foreach (int szam in szamok)
            {
                Console.WriteLine(szam);
            }
        }
    }
}
