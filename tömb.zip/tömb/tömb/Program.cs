﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tömb
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("add meg az osztály matekátlagát");
            double[] jegyek = new double[10];
            double osszeg = 0;
            
            for (int i = 0; i < jegyek.Length; i++)
            {
                Console.WriteLine("kérem az "  + (i + 1) + ". tanuló átlagát");
                jegyek[i] = double.Parse(Console.ReadLine());
                osszeg += jegyek[i];



            }
            double atlag = (double)osszeg / 10;
            int darab = 0;
            for (int i = 0; i < jegyek.Length; i++)
            {
                if (jegyek[i] > atlag)
                    darab++;

            }
            Console.WriteLine($"ennyien értek el az átlagnál jobb eredményt: {darab}");
            Console.WriteLine($"Az átlaguk: {atlag}");
            Console.ReadKey();


        }
    }
}
